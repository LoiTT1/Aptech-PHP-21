<form action="<?php echo e(route('users.update',$user->id)); ?>" method="POST">
   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
   <input type="hidden" name="_method" value="PUT">
   <input type="text" value="<?php echo e($user->name); ?>" name="name">
   <input type="email" value="<?php echo e($user->email); ?>" name="email">
   <button type="submit"> cap nhat du lieu</button>
   </form>
