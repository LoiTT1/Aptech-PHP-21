<form action="http://localhost:8000/users/create">
  <button type="submit">Tao Nguoi Dung Moi</button>
</form>
<table>
  <thead>
    <tr>
      <th>id</th>
      <th>name</th>
      <th>email</th>
      <th>action</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($user->id); ?></td>
      <td><?php echo e($user->name); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td>
        <form action="<?php echo e(asset('/users/' .$user->id)); ?>" method="GET">
          <button type="submit">Xem Nguoi Nay</button>
          
        </form>
        <form action="<?php echo e(asset('/users/' .$user->id)); ?>" method="POST">
          <input type="hidden" name="_token" value=<?php echo e(csrf_token()); ?>>
          <input type="hidden" name="_method" value="DELETE">
          <button type="submit">Xoa Nguoi Nay</button>
         </form>
         <form action="<?php echo e(asset('/users/'.$user->id.'/edit')); ?>" method="GET">
          <button type="submit">Sua Nguoi Nay</button>
        </form>
          

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>