<form>
<form action="http://127.0.0.1:8000/users" method="POST">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<div>
   <label for="">Name</label>
   <input type="text" name="name">
</div>
<div>
   <label for="">Email</label>
   <input type="email" name="email">
</div>
<div>
   <label for="">PASSWORD</label>
   <input type="password" name="password">
</div>

 <button type="submit">Dang Ky Tai Khoan>
 </button>
</form> 