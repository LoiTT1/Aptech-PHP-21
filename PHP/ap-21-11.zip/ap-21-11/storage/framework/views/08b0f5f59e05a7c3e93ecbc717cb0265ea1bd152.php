<h1>Day La Nguoi Dung Thu <?php echo e($user->id); ?></h1>
<h1><?php echo e($user->name); ?></h1>