<h1>Day La Nguoi Dung Thu {{$user->id}}</h1>
<h1>{{$user->name}}</h1>